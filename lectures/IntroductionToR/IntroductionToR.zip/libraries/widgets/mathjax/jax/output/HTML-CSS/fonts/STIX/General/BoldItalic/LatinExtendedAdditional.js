/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/BoldItalic/LatinExtendedAdditional.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["STIXGeneral-bold-italic"],{7808:[904,18,889,64,940],7809:[697,13,667,15,614],7810:[904,18,889,64,940],7811:[697,13,667,15,614],7812:[862,18,889,64,940],7813:[655,13,667,15,614],7922:[904,0,611,71,659],7923:[697,205,444,-94,392]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/BoldItalic/LatinExtendedAdditional.js");

